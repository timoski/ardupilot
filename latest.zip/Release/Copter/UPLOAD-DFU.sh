#!/bin/sh

#production binary for bootloader
dfu-util -a 0 --dfuse-address 0x08010000:leave -D $1


